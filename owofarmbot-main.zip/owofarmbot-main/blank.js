import wa from 'aixlib';
var owocollection = wa.collection(Test);
const Test = {

"1":"9",
"6":"44",
"942": "2609",
"autogem": "has",
"autouse":"has",
"checkinv":"has"
"autoseed":"nav"
}
